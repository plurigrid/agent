# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poet']

package_data = \
{'': ['*']}

install_requires = \
['langchain>=0.0.92,<0.0.93',
 'llama-index>=0.4.8,<0.5.0',
 'pypdf2>=3.0.1,<4.0.0',
 'unstructured>=0.4.11,<0.5.0',
 'wandb>=0.13.10,<0.14.0']

setup_kwargs = {
    'name': 'poet',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Plurigrid',
    'author_email': 'gm@plurigrid.xyz',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<3.12',
}


setup(**setup_kwargs)
